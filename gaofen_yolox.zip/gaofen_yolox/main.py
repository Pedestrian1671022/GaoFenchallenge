import os
import cv2
import time
import torch
import numpy as np
from loguru import logger
from yolox.exp import build
from yolox.utils import postprocess
from yolox.data.data_augment import ValTransform
from yolox.data.datasets import COCO_CLASSES


class Predictor(object):
    def __init__(
        self,
        model,
        exp,
        cls_names=COCO_CLASSES,
        device="cpu",
        legacy=False,
    ):
        self.model = model
        self.cls_names = cls_names
        self.num_classes = exp.num_classes
        self.confthre = exp.test_conf
        self.nmsthre = exp.nmsthre
        self.test_size = exp.test_size
        self.device = device
        self.preproc = ValTransform(legacy=legacy)

    def inference(self, img):
        img_info = {"id": 0}
        if isinstance(img, str):
            img_info["file_name"] = img
            img = cv2.imread(img)
            _img = np.zeros((1088, 1920, 3))
            _img[0: 1080, :, :] = img
            img = _img
        else:
            img_info["file_name"] = None

        height, width = img.shape[:2]
        img_info["height"] = height
        img_info["width"] = width
        img_info["raw_img"] = img

        ratio = min(self.test_size[0] / img.shape[0], self.test_size[1] / img.shape[1])
        img_info["ratio"] = ratio

        img, _ = self.preproc(img, None, self.test_size)
        img = torch.from_numpy(img).unsqueeze(0)
        if self.device == "gpu":
            img = img.cuda()

        with torch.no_grad():
            t0 = time.time()
            outputs = self.model(img)
            outputs = postprocess(
                outputs, self.num_classes, self.confthre,
                self.nmsthre, class_agnostic=True
            )
            logger.info("Infer time: {:.4f}s".format(time.time() - t0))
        return outputs, img_info

    def adjust(self, output, img_info, cls_conf=0.05):
        ratio = img_info["ratio"]
        output = output.cpu()
        bboxes = output[:, 0:4]
        bboxes /= ratio

        cls = output[:, 6]
        scores = output[:, 4] * output[:, 5]

        _bboxes = []

        for i in range(len(bboxes)):
            box = bboxes[i]
            cls_id = int(cls[i])
            score = scores[i]
            if score < cls_conf:
                continue
            x0 = box[0]
            y0 = box[1]
            x1 = box[2]
            y1 = box[3]

            _bboxes.append([x0, y0, x1, y1, score, cls_id + 1])
        return _bboxes

def get_image_list(path):
    image_names = []
    for maindir, subdir, file_name_list in os.walk(path):
        for filename in file_name_list:
            apath = os.path.join(maindir, filename)
            image_names.append(apath)
    return image_names

def iou(bbox1, bbox2):
    bbox1 = [float(x) for x in bbox1]
    bbox2 = [float(x) for x in bbox2]
    (x0_1, y0_1, x1_1, y1_1) = bbox1
    (x0_2, y0_2, x1_2, y1_2) = bbox2
    overlap_x0 = max(x0_1, x0_2)
    overlap_y0 = max(y0_1, y0_2)
    overlap_x1 = min(x1_1, x1_2)
    overlap_y1 = min(y1_1, y1_2)
    if overlap_x1 - overlap_x0 <= 0 or overlap_y1 - overlap_y0 <= 0:
        return 0
    size_1 = (x1_1 - x0_1) * (y1_1 - y0_1)
    size_2 = (x1_2 - x0_2) * (y1_2 - y0_2)
    size_intersection = (overlap_x1 - overlap_x0) * (overlap_y1 - overlap_y0)
    size_union = size_1 + size_2 - size_intersection
    return size_intersection / size_union

def track_iou(detections, tracks_active, sigma_l, sigma_h, sigma_iou, t_life, t_loss, id):
    tracks_finished = []
    dets_1 = [det for det in detections if det['score'] >= sigma_l and det['cls'] == 1]
    dets_2 = [det for det in detections if det['score'] >= sigma_l and det['cls'] == 2]
    updated_tracks = []
    for track in tracks_active:
        if track['cls'] == 1:
            if len(dets_1) > 0:
                best_match = max(dets_1, key=lambda x: iou(track['bboxes'], x['bbox']))
                if iou(track['bboxes'], best_match['bbox']) >= sigma_iou:
                    track['bboxes'] = best_match['bbox']
                    track['max_score'] = max(track['max_score'], best_match['score'])
                    track['life_time'] += 1
                    track['loss_time'] = 0
                    updated_tracks.append(track)
                    del dets_1[dets_1.index(best_match)]
                    if track['max_score'] >= sigma_h and track['life_time'] >= t_life:
                        if track['id'] == 0:
                            id += 1
                            track['id'] = id
                        tracks_finished.append(track)
            if len(updated_tracks) == 0 or track is not updated_tracks[-1]:
                track['loss_time'] += 1
                if track['loss_time'] > 5:
                    track['life_time'] = 0
                if track['loss_time'] >= t_loss:
                    tracks_active.remove(track)
        else:
            if len(dets_2) > 0:
                best_match = max(dets_2, key=lambda x: iou(track['bboxes'], x['bbox']))
                if iou(track['bboxes'], best_match['bbox']) >= sigma_iou:
                    track['bboxes'] = best_match['bbox']
                    track['max_score'] = max(track['max_score'], best_match['score'])
                    track['life_time'] += 1
                    track['loss_time'] = 0
                    updated_tracks.append(track)
                    del dets_2[dets_2.index(best_match)]
                    if track['max_score'] >= sigma_h and track['life_time'] >= t_life:
                        if track['id'] == 0:
                            id += 1
                            track['id'] = id
                        tracks_finished.append(track)
            if len(updated_tracks) == 0 or track is not updated_tracks[-1]:
                track['loss_time'] += 1
                if track['loss_time'] > 5:
                    track['life_time'] = 0
                if track['loss_time'] >= t_loss:
                    tracks_active.remove(track)
    new_tracks_1 = [{'bboxes': det['bbox'], 'max_score': det['score'], 'life_time': 1, 'loss_time': 0, 'id': 0, 'cls': det['cls']} for det in dets_1]
    new_tracks_2 = [{'bboxes': det['bbox'], 'max_score': det['score'], 'life_time': 1, 'loss_time': 0, 'id': 0, 'cls': det['cls']} for det in dets_2]
    tracks_active = tracks_active + new_tracks_1 + new_tracks_2
    return tracks_finished, tracks_active, id

def convertBack(xmin, ymin, xmax, ymax, conf, cls):
    xmin = int(xmin) - 2
    xmax = int(xmax) + 2
    ymin = int(ymin) - 2
    ymax = int(ymax) + 2
    return [xmin, ymin, xmax, ymax], conf, int(cls)

def image_demo(predictor, output_path, input_path):
    for subdir in os.listdir(os.path.join(input_path)):
        files = get_image_list(os.path.join(input_path, subdir, 'img'))
        files.sort()
        lines = []
        tracks_active = []
        id = 0
        for image_name in files:
            outputs, img_info = predictor.inference(image_name)
            bboxes = predictor.adjust(outputs[0], img_info, predictor.confthre)
            bboxes = [convertBack(float(bbox[0]), float(bbox[1]), float(bbox[2]), float(bbox[3]), float(bbox[4]), float(bbox[5])) for bbox in bboxes]
            detections = [{'bbox': bbox, 'score': conf, 'cls': cls} for bbox, conf, cls in bboxes]
            tracks_finished, tracks_active, id = track_iou(detections, tracks_active, 0.05, 0.4, 0.01, 5, 10, id)
            for track_finished in tracks_finished:
                bbox = track_finished['bboxes']
                line = '{},{},{},{},{},{},{},{},{}'.format(int(image_name[-10:-4]), track_finished['id'], bbox[0]+2, bbox[1]+2, bbox[2]-bbox[0]-4, bbox[3]-bbox[1]-4, 1, track_finished['cls'], 1)
                _lines = lines
                flag_1 = False
                flag_2 = False
                flag_3 = False
                flag_4 = False
                for _line in _lines:
                    if _line.startswith('{},{},'.format(int(image_name[-10:-4]) - 1, track_finished['id'])):
                        flag_1 = True
                    if _line.startswith('{},{},'.format(int(image_name[-10:-4]) - 2, track_finished['id'])):
                        flag_2 = True
                    if _line.startswith('{},{},'.format(int(image_name[-10:-4]) - 3, track_finished['id'])):
                        flag_3 = True
                    if _line.startswith('{},{},'.format(int(image_name[-10:-4]) - 4, track_finished['id'])):
                        flag_4 = True
                if not flag_1:
                    lines.append('{},{},{},{},{},{},{},{},{}'.format(int(image_name[-10:-4]) - 1, track_finished['id'],
                                                                     bbox[0] + 2, bbox[1] + 2, bbox[2] - bbox[0] - 4,
                                                                     bbox[3] - bbox[1] - 4, 1, track_finished['cls'],
                                                                     1))
                if not flag_2:
                    lines.append('{},{},{},{},{},{},{},{},{}'.format(int(image_name[-10:-4]) - 2, track_finished['id'],
                                                                     bbox[0] + 2, bbox[1] + 2, bbox[2] - bbox[0] - 4,
                                                                     bbox[3] - bbox[1] - 4, 1, track_finished['cls'],
                                                                     1))
                if not flag_3:
                    lines.append('{},{},{},{},{},{},{},{},{}'.format(int(image_name[-10:-4]) - 3, track_finished['id'],
                                                                     bbox[0] + 2, bbox[1] + 2, bbox[2] - bbox[0] - 4,
                                                                     bbox[3] - bbox[1] - 4, 1, track_finished['cls'],
                                                                     1))
                if not flag_4:
                    lines.append('{},{},{},{},{},{},{},{},{}'.format(int(image_name[-10:-4]) - 4, track_finished['id'],
                                                                     bbox[0] + 2, bbox[1] + 2, bbox[2] - bbox[0] - 4,
                                                                     bbox[3] - bbox[1] - 4, 1, track_finished['cls'],
                                                                     1))
                lines.append(line)
        with open(os.path.join(output_path, subdir + '.txt'), 'w') as f:
            lines.sort(key=lambda line:(int(line.split(',')[1]), int(line.split(',')[0])))
            for line in lines:
                f.write(line + '\n')



def main(exp):
    model = exp.get_model()
    model.cuda()
    model.eval()

    ckpt_file = os.path.join("best_ckpt.pth")
    logger.info("loading checkpoint")
    ckpt = torch.load(ckpt_file, map_location="cpu")
    model.load_state_dict(ckpt["model"])
    logger.info("loaded checkpoint done.")

    predictor = Predictor(model, exp, COCO_CLASSES, "gpu", False)
    image_demo(predictor, "/output_path", "/input_path")


if __name__ == "__main__":
    exp = build.get_exp_by_name('yolox-s')
    main(exp)
