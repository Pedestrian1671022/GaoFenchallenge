import os
import cv2
import argparse
import numpy as np


def xml_to_text(data_path, images, labels):
    dirs = os.listdir(os.path.join(data_path, labels))

    for _dir in dirs:
        if not os.path.exists(os.path.join(data_path, '_images', _dir)):
            os.mkdir(os.path.join(data_path, '_images', _dir))
        if not os.path.exists(os.path.join(data_path, '_labels', _dir)):
            os.mkdir(os.path.join(data_path, '_labels', _dir))

        image_inds = [txt[0:-4] for txt in os.listdir(os.path.join(data_path, labels, _dir))]
        i = -1
        for image_ind in image_inds:
            i = i + 1
            if i % 30 == 0:
                with open(os.path.join(data_path, labels, _dir, image_ind + '.txt'), 'r') as label:
                    boxes = np.array([list(map(float, line.split(' '))) for line in label.readlines()])
                    if len(boxes) != 0:
                        boxes[:, [1, 3]] = boxes[:, [1, 3]] * 1920
                        boxes[:, [2, 4]] = boxes[:, [2, 4]] * 1080
                        boxes[:, 2] = boxes[:, 2] + 100

                image = cv2.imread(os.path.join(data_path, images,  _dir, image_ind + '.jpg'))
                h, w, c  = image.shape
                _image = np.zeros((h + 200, w, 3))
                _image[100 : h + 100, :, :] = image

                h_splits = [0, 320, 640]
                w_splits = [0, 320, 640, 960, 1280]
                for h_split in h_splits:
                    for w_split in w_splits:
                        __image = _image[h_split : h_split + 640, w_split : w_split + 640, :]
                        _boxes = np.array([list(box) for box in boxes if w_split < box[1] < w_split + 640 and h_split < box[2] < h_split + 640])
                        if len(_boxes) != 0:
                            _boxes[:, 1] = _boxes[:, 1] - w_split
                            _boxes[:, 2] = _boxes[:, 2] - h_split
                            _boxes = np.concatenate([_boxes[:, :1], np.concatenate([_boxes[:, 1:3] - _boxes[:, 3:] * 0.5,
                                                        _boxes[:, 1:3] + _boxes[:, 3:] * 0.5], axis=-1)], axis=-1)
                            # print(_boxes, image_ind)
                            _boxes[:, 1] = np.array([max(elem, 0) / 640 for elem in _boxes[:, 1]])
                            _boxes[:, 2] = np.array([max(elem, 0) / 640 for elem in _boxes[:, 2]])
                            _boxes[:, 3] = np.array([min(elem, 640) / 640 for elem in _boxes[:, 3]])
                            _boxes[:, 4] = np.array([min(elem, 640) / 640 for elem in _boxes[:, 4]])
                            _boxes = np.concatenate([_boxes[:, :1], np.concatenate([(_boxes[:, 1:3] + _boxes[:, 3:]) * 0.5,
                                                                                    (_boxes[:, 3:] - _boxes[:, 1:3])],
                                                                                   axis=-1)], axis=-1)
                        # print(_boxes)
                        cv2.imwrite(os.path.join(data_path, '_images', _dir, image_ind + '_' + str(w_split) + '_' + str(h_split) + '.jpg'), __image)
                        with open(os.path.join(data_path, '_labels', _dir,
                                                 image_ind + '_' + str(w_split) + '_' + str(h_split) + '.txt'), 'w') as f:
                            for _box in _boxes:
                                f.write(str(int(_box[0])) + ' ' + str(float(_box[1])) + ' ' + str(float(_box[2])) + ' ' +
                                        str(float(_box[3])) + ' ' + str(float(_box[4])) + '\n')





if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_path", default="datasets/gaofenchallenge/train")
    flags = parser.parse_args()

    xml_to_text(flags.data_path, 'images', 'labels')
