import os
import cv2
import argparse
import numpy as np


def xml_to_text(data_path, images, labels):
    dirs = os.listdir(os.path.join(data_path, labels))

    for _dir in dirs:
        image_inds = [txt[0:-4] for txt in os.listdir(os.path.join(data_path, labels, _dir))]
        i = -1
        for image_ind in image_inds:
            i = i + 1
            if i % 10 == 0:
                image = cv2.imread(os.path.join(data_path, images,  _dir, image_ind + '.jpg'))
                h, w, c  = image.shape
                _image = np.zeros((h + 8, w, 3))
                _image[0 : h, :, :] = image

                with open(os.path.join(data_path, labels, _dir, image_ind + '.txt'), 'r') as label:
                    boxes = np.array([list(map(float, line.split(' '))) for line in label.readlines()])
                    if len(boxes) == 0:
                        with open(os.path.join(data_path, '_labels', image_ind + '.txt'), 'w') as f:
                            cv2.imwrite(os.path.join(data_path, '_images', image_ind + '.jpg'), _image)
                        continue
                    boxes[:, [1, 3]] = boxes[:, [1, 3]] * 1920
                    boxes[:, [2, 4]] = boxes[:, [2, 4]] * 1080

                _boxes = np.concatenate([boxes[:, :1], np.concatenate([boxes[:, 1:3] - boxes[:, 3:] * 0.5,
                                            boxes[:, 1:3] + boxes[:, 3:] * 0.5], axis=-1)], axis=-1)
                # print(_boxes, image_ind)
                _boxes[:, 1] = np.array([elem / 1920 for elem in _boxes[:, 1]])
                _boxes[:, 2] = np.array([elem / 1088 for elem in _boxes[:, 2]])
                _boxes[:, 3] = np.array([elem / 1920 for elem in _boxes[:, 3]])
                _boxes[:, 4] = np.array([elem / 1088 for elem in _boxes[:, 4]])
                _boxes = np.concatenate([_boxes[:, :1], np.concatenate([(_boxes[:, 1:3] + _boxes[:, 3:]) * 0.5,
                                                                        (_boxes[:, 3:] - _boxes[:, 1:3])],
                                                                       axis=-1)], axis=-1)
                # print(_boxes)
                cv2.imwrite(os.path.join(data_path, '_images', image_ind + '.jpg'), _image)
                with open(os.path.join(data_path, '_labels', image_ind + '.txt'), 'w') as f:
                    for _box in _boxes:
                        f.write(str(int(_box[0])) + ' ' + str(float(_box[1])) + ' ' + str(float(_box[2])) + ' ' +
                                str(float(_box[3])) + ' ' + str(float(_box[4])) + '\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_path", default="datasets/gaofenchallenge/train")
    flags = parser.parse_args()

    xml_to_text(flags.data_path, 'images', 'labels')
