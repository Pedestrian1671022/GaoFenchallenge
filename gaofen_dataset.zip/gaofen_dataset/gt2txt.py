import os
import cv2
import shutil
import argparse


def xml_to_text(data_path, video, gt):
    dirs = os.listdir(os.path.join(data_path, video))

    for _dir in dirs:
        if not os.path.exists(os.path.join(data_path, 'images', _dir)):
            os.mkdir(os.path.join(data_path, 'images', _dir))
        if not os.path.exists(os.path.join(data_path, 'labels', _dir)):
            os.mkdir(os.path.join(data_path, 'labels', _dir))

        image_inds = [jpg[0:-4] for jpg in os.listdir(os.path.join(data_path, video, _dir, 'img'))]
        gt_path = os.path.join(data_path, gt, _dir + '.txt')
        with open(gt_path, 'r') as gt_f:
            lines = [line.split(',') for line in gt_f.readlines()]

        for image_ind in image_inds:
            image_path = os.path.join(data_path, video,  _dir, 'img', image_ind + '.jpg')
            shutil.copy(image_path, os.path.join(data_path, 'images', _dir, _dir.zfill(4) + '_' + image_ind + '.jpg'))
            image = cv2.imread(image_path)
            h, w, _  = image.shape

            with open(os.path.join(data_path, 'labels', _dir, _dir.zfill(4) + '_' + image_ind + '.txt'), 'w') as f:
                for line in lines:
                    if int(line[0]) == int(image_ind):
                        txt = ' '.join([str(int(line[-2]) - 1), str((float(line[2]) + float(line[4]) * 0.5) / w), str((float(line[3]) + float(line[5]) * 0.5) / h), str(float(line[4]) / w), str(float(line[5]) / h)])
                        f.write(txt + '\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_path", default="datasets/gaofenchallenge/train")
    flags = parser.parse_args()

    xml_to_text(flags.data_path, 'video', 'gt')
